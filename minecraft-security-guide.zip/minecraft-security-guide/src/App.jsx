
import { motion } from "framer-motion";
import { Shield, Lock, Mail, AlertTriangle } from "lucide-react";

const steps = [
{
title:"Enable 2FA",
desc:"Turn on Microsoft two-factor authentication to secure your Minecraft account.",
link:"https://account.microsoft.com/security"
},
{
title:"Use a Strong Password",
desc:"Use a unique password that is not reused on Discord or other sites.",
link:"#"
},
{
title:"Avoid Fake Verification",
desc:"Never enter Microsoft login codes into Discord bots or fake websites.",
link:"#"
},
{
title:"Secure Your Email",
desc:"Your email account controls your Minecraft account recovery.",
link:"#"
}
]

export default function App(){
return(
<div style={{
minHeight:"100vh",
background:"#050505",
position:"relative",
overflow:"hidden"
}}>

<div style={{
position:"fixed",
inset:0,
backgroundImage:"url(https://images.unsplash.com/photo-1627856014754-2907e2355d1d?q=80&w=2070&auto=format&fit=crop)",
backgroundSize:"cover",
backgroundPosition:"center",
opacity:0.18
}}/>

<div style={{
position:"fixed",
inset:0,
background:"linear-gradient(to bottom,rgba(0,0,0,.4),rgba(0,0,0,.95))"
}}/>

<div style={{position:"relative",zIndex:2}}>

<nav style={{
display:"flex",
justifyContent:"space-between",
padding:"20px 40px",
borderBottom:"1px solid rgba(255,255,255,.1)",
backdropFilter:"blur(10px)"
}}>
<h1 style={{fontSize:"28px"}}>Minecraft Security Guide</h1>

<a href="#guide" style={{
textDecoration:"none",
padding:"14px 22px",
background:"#67ff67",
color:"black",
borderRadius:"14px",
fontWeight:"bold"
}}>
Start Guide
</a>
</nav>

<section style={{
minHeight:"85vh",
display:"flex",
alignItems:"center",
justifyContent:"center",
flexDirection:"column",
textAlign:"center",
padding:"20px"
}}>

<motion.h1
initial={{opacity:0,y:40}}
animate={{opacity:1,y:0}}
transition={{duration:1}}
style={{
fontSize:"clamp(50px,8vw,100px)",
maxWidth:"1100px",
lineHeight:"1.1"
}}>
Secure Your Minecraft Account
</motion.h1>

<motion.p
initial={{opacity:0}}
animate={{opacity:1}}
transition={{delay:.4}}
style={{
fontSize:"22px",
maxWidth:"900px",
marginTop:"25px",
opacity:.85,
lineHeight:"1.7"
}}>
Simple beginner-friendly guide to protect your Microsoft & Minecraft account from phishing and scams.
</motion.p>

<div style={{
display:"flex",
gap:"20px",
marginTop:"40px",
flexWrap:"wrap",
justifyContent:"center"
}}>
<Card icon={<Shield/>} text="Trusted"/>
<Card icon={<Lock/>} text="Secure"/>
<Card icon={<AlertTriangle/>} text="Anti Scam"/>
</div>

</section>

<section id="guide" style={{
padding:"80px 30px",
maxWidth:"1300px",
margin:"auto"
}}>

<h2 style={{
fontSize:"58px",
textAlign:"center",
marginBottom:"50px"
}}>
Security Steps
</h2>

<div style={{
display:"grid",
gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))",
gap:"30px"
}}>
{steps.map((s,i)=>(
<motion.a
whileHover={{scale:1.03}}
href={s.link}
key={i}
style={{
textDecoration:"none",
color:"white",
background:"rgba(255,255,255,.05)",
padding:"35px",
borderRadius:"30px",
border:"1px solid rgba(255,255,255,.08)",
backdropFilter:"blur(15px)",
boxShadow:"0 0 30px rgba(0,255,120,.08)"
}}>
<div style={{
width:"70px",
height:"70px",
borderRadius:"20px",
display:"flex",
alignItems:"center",
justifyContent:"center",
background:"rgba(103,255,103,.12)"
}}>
<Mail size={34}/>
</div>

<h3 style={{
fontSize:"32px",
marginTop:"25px"
}}>
{s.title}
</h3>

<p style={{
opacity:.8,
lineHeight:"1.8",
marginTop:"14px",
fontSize:"18px"
}}>
{s.desc}
</p>

<div style={{
marginTop:"25px",
display:"inline-block",
padding:"12px 18px",
background:"#67ff67",
borderRadius:"12px",
color:"black",
fontWeight:"bold"
}}>
Open Step
</div>
</motion.a>
))}
</div>

</section>

<footer style={{
padding:"30px",
textAlign:"center",
opacity:.6
}}>
© 2026 Minecraft Security Guide
</footer>

</div>
</div>
)
}

function Card({icon,text}){
return(
<div style={{
display:"flex",
alignItems:"center",
gap:"12px",
padding:"18px 26px",
background:"rgba(255,255,255,.06)",
borderRadius:"18px",
border:"1px solid rgba(255,255,255,.08)"
}}>
{icon}
{text}
</div>
)
}
